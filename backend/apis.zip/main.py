def main():
    print("Hello from begautos!")


if __name__ == "__main__":
    main()
