from apps.home.models.slider_model import Slider
from apps.home.models.socialmedia_model import SocialMedia
from apps.home.models.sell_car_model import SellCar
from apps.home.models.people_talk_model import PeopleTalkAboutUs
from apps.home.models.sell_your_cars_image_model import SellYourCarImages
from apps.home.models.subscribers_model import Subscriber
from apps.home.models.sales_representative import SalesRepresentative
